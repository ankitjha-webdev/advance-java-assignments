package spring.mvc.collegemvc.jdbc;

public class JdbcDemo {

	public static void main(String[] args) {
		
		
		
	}
}
